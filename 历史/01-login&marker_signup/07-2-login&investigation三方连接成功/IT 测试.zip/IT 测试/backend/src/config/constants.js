module.exports = {
  ROLES: {
    COORDINATOR: 'COORDINATOR',
    MARKER: 'MARKER'
  },
  INVITATION_EXPIRY_HOURS: 24
};